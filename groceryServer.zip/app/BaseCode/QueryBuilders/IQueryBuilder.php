<?php

namespace App\BaseCode\QueryBuilders;

Interface IQueryBuilder {
    public function getQuery($values,$tableNAme);
 }

?>