<?php

namespace App\BaseCode;

class Enums {

    public static function value($var) {
        return $var->value;
    }

    public static function key($var) {
        return $var->key;
    }
}

?>