<?php

namespace App\DeliveryManPbModule;

use Exception;
use App\Interfaces\ISearcher;

class DeliveryManSearcher implements ISearcher{

    public function search($pb){
        $searchArray = array();
        return $searchArray;
    }
}

?>