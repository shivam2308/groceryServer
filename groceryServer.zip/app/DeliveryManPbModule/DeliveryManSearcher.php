<?php

namespace App\DeliveryManPbModule;

use App\Interfaces\ISearcher;

class DeliveryManSearcher implements ISearcher{

    public function search($pb){
        $searchArray = array();
        return $searchArray;
    }
}

?>