<?php


namespace App\ImagePbModule;


use App\Interfaces\ISearcher;

class ImageSearcher implements ISearcher
{

    public function search($pb)
    {
        $searchArray = array();

        return $searchArray;
    }
}
