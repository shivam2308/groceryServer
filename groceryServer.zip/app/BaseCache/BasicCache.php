<?php

namespace App\BaseCache;

use Memcache;
use Doctrine\Common\Cache\MemcacheCache;

class BasicCache {

}

?>