<?php

namespace App\Interfaces;

Interface ITableName {
    public static function getTableName();
    public static function getcolumnIndexes();
 }

?>
