<?php

namespace App\Interfaces;

Interface IHandler {
    public function handle();
 }

?>