<?php

namespace App\Interfaces;

interface IConvertor
{
    public function convert($array);
    public function refConvert($array);
}
