<?php

namespace App\Interfaces;

Interface ISearcher {
    public function search($pb);
 }

?>