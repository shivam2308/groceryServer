<?php

namespace App\Interfaces;

interface IUpdator
{
    public function update($pb);
    public function refUpdate($pb);
}
