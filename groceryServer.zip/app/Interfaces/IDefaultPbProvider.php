<?php

namespace App\Interfaces;

Interface IDefaultPbProvider {
    public function getDefaultPb();
    public function getDefaultRefPb();
 }

?>
