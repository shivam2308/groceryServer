<?php

namespace App\LoginPbModule;

use BenSampo\Enum\Enum;
use App\BaseCode\Enums;

class LoginIndexers extends Enum
{
}
